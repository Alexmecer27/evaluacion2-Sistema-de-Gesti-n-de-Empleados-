﻿using System.ComponentModel.DataAnnotations;

namespace GestionEmpleadosAPI.Models
{
    public class Empleado
    {
        [Key]
        public int EmpleadoId { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Email { get; set; }
        public string Telefono { get; set; }
    }
}