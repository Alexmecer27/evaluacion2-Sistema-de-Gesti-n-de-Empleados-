﻿using System.ComponentModel.DataAnnotations;

namespace GestionEmpleadosAPI.Models
{
    public class Asignacion
    {
        [Key]
        public int AsignacionId { get; set; }
        public int DepartamentoId { get; set; }
        public int EmpleadoId { get; set; }
        public DateTime FechaAsignacion { get; set; }
    }
}