﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GestionEmpleadosAPI.Models
{
    public class Departamento
    {
        [Key]
        public int DepartamentoId { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Ubicacion { get; set; }
        public int? JefeDepartamento { get; set; } // FK a Empleado
        public string Extension { get; set; }
    }
}