﻿using Microsoft.EntityFrameworkCore;
using GestionEmpleadosAPI.Models;

namespace GestionEmpleadosAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Departamento> Departamentos { get; set; }
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<Asignacion> Asignaciones { get; set; }
    }
}